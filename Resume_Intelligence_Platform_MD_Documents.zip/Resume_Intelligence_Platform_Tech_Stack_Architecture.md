---
title: Technical Stack & Architecture Recommendation
---

**Resume Intelligence Platform**

Version 1.0 \| Recommended Stack for a scalable AI resume parser

# 1. Executive Recommendation

Use a TypeScript-first Next.js frontend and a Python/FastAPI
AI-processing backend, with PostgreSQL as the system of record and
pgvector for semantic search. Put document parsing and AI extraction
behind an asynchronous worker queue, store original resumes in object
storage, and instrument the system with OpenTelemetry.

This split is intentional: the frontend benefits from the React/Next.js
ecosystem and animation tooling, while Python provides a stronger
ecosystem for document processing, OCR, data validation, and AI/ML
workflows.

# 2. Recommended Stack --- At a Glance

  ----------------------------------------------------------------------------
  Layer             Recommendation      Role                 Priority
  ----------------- ------------------- -------------------- -----------------
  Frontend          Next.js 16 +        Web application      P0
                    TypeScript                               

  UI                Tailwind CSS +      Design system        P0
                    shadcn/ui                                

  Animation         Motion for React    Premium              P0
                                        interaction/motion   

  API               FastAPI + Python    REST API             P0

  Validation        Pydantic v2         Typed extraction     P0
                                        schemas              

  Document parsing  PyMuPDF +           PDF/DOCX extraction  P0
                    python-docx                              

  OCR               PaddleOCR           Scanned/image        P0
                                        resumes              

  AI                Provider-agnostic   Semantic extraction  P0
                    structured-output                        
                    LLM                                      

  Database          PostgreSQL 18       System of record     P0

  Vector search     pgvector            Embeddings and       P1
                                        semantic search      

  Queue             Redis + ARQ         Async jobs           P0

  Object storage    Amazon S3           Resume files         P0

  Auth              Auth.js or managed  Authentication       P1
                    OIDC provider                            

  Observability     OpenTelemetry +     Traces, metrics,     P1
                    Sentry              errors               

  Testing           Pytest +            Automated testing    P0
                    Playwright + Vitest                      

  Containers        Docker + Docker     Local/dev            P0
                    Compose             consistency          

  CI/CD             GitHub Actions      Build/test/deploy    P0

  Production        AWS ECS/Fargate +   Scalable deployment  P1
                    RDS + S3                                 
  ----------------------------------------------------------------------------

# 3. Frontend

## 3.1 Next.js + TypeScript

Use Next.js 16 with the App Router and TypeScript. Next.js is a React
framework for full-stack web applications and its current 16.x line is
actively maintained; the official site lists Next.js 16.3 as a current
2026 release and documents the App Router.
citeturn0search2turn0search3

-   Server Components for data-heavy/static UI.

-   Client Components only where interaction or animation requires them.

-   Route handlers/server actions where appropriate.

-   Typed API client shared through generated OpenAPI types.

## 3.2 Tailwind CSS + shadcn/ui

Use Tailwind for layout and design tokens, with shadcn/ui-style
accessible primitives for dialogs, dropdowns, tabs, tables, command
palettes, and forms.

-   Keep product-specific visual identity in your own token layer.

-   Avoid excessive prebuilt-dashboard styling.

## 3.3 Motion

Use Motion for React for page transitions, upload states, parsing
pipeline animation, metric counters, card interactions, and
evidence-panel transitions.

-   Prefer transform/opacity animations.

-   Support prefers-reduced-motion.

-   Keep animation state separate from business state.

# 4. Backend

## 4.1 FastAPI + Python

FastAPI is a strong fit for the API because the application needs
asynchronous I/O around uploads, databases, object storage, and model
providers, while Python also gives direct access to the
document-processing and AI ecosystem. FastAPI documents async/await
support and mixing async and sync path operations. citeturn0search7

-   REST API

-   OpenAPI schema generation

-   Request/response validation

-   Authentication middleware

-   Rate limiting

-   Job submission/status endpoints

## 4.2 Pydantic v2

Use Pydantic as the canonical schema layer between LLM output and
application persistence.

-   LLM output → Pydantic model

-   Business validation → normalized domain model

-   Domain model → PostgreSQL

# 5. Document Processing

## 5.1 PDF

Use PyMuPDF as the primary text/layout extraction layer. Preserve page
numbers, text blocks, bounding boxes, and metadata when available.

## 5.2 DOCX

Use python-docx for paragraphs, headings, tables, lists, and hyperlinks.

## 5.3 OCR

Use PaddleOCR for scanned resumes and image-heavy documents. The
pipeline should detect when normal text extraction is insufficient and
route only those pages through OCR.

# 6. AI / LLM Layer

Do not hard-code the product to one model provider. Implement an
internal AI adapter.

Recommended abstraction:

-   ExtractionProvider

-   EmbeddingProvider

-   Optional VisionProvider

The extraction provider should request structured output matching the
Pydantic schema. Persist model name/version, prompt version, extraction
run ID, latency, and token/cost metadata.

The application should be able to switch providers without changing the
domain layer.

# 7. Database

## 7.1 PostgreSQL

Use PostgreSQL as the primary source of truth for users, resumes,
candidate profiles, extracted entities, evidence, processing jobs,
corrections, and audit metadata.

## 7.2 pgvector

Use pgvector instead of introducing a separate vector database in the
first production version. pgvector stores vectors alongside PostgreSQL
data and supports exact and approximate nearest-neighbor search,
including cosine distance and HNSW/IVFFlat indexing options.
citeturn0search1turn0search10

-   Resume embeddings

-   Project embeddings

-   Experience embeddings

-   Skill/entity embeddings

-   Semantic job-description matching

# 8. Async Processing

Resume parsing should never depend on a long-running HTTP request.

Recommended flow:

Upload → API creates processing record → object storage → queue → worker
→ parse/OCR → LLM extraction → validation → normalization → embeddings →
database → status=completed

Use Redis + ARQ for the initial implementation. If the workload later
requires durable, complex, multi-step workflows with long-running
retries and compensation, evaluate Temporal as a second-stage migration.

# 9. Object Storage

Store original resumes and generated document artifacts in Amazon S3 or
an S3-compatible service. Store only metadata and references in
PostgreSQL.

-   Private buckets

-   Short-lived signed URLs

-   Server-side encryption

-   Lifecycle rules for temporary artifacts

-   Retention/deletion policy

# 10. Authentication and Authorization

For a portfolio/MVP, Auth.js or a managed OIDC provider can reduce
authentication complexity. For a multi-tenant production product, model
users, organizations, memberships, roles, and API keys explicitly.

-   User

-   Organization

-   Membership

-   Role

-   API key

-   Resume access policy

# 11. API Design

-   POST /api/v1/resumes --- upload and create processing job

-   GET /api/v1/resumes/{id} --- retrieve resume metadata

-   GET /api/v1/resumes/{id}/status --- retrieve processing status

-   GET /api/v1/resumes/{id}/profile --- retrieve structured candidate
    profile

-   GET /api/v1/resumes/{id}/evidence --- retrieve evidence records

-   POST /api/v1/search --- structured + semantic candidate search

-   PATCH /api/v1/resumes/{id}/profile --- submit human corrections

# 12. Repository Architecture

Use a monorepo so the frontend, backend contracts, infrastructure, and
documentation evolve together.

Suggested structure:

-   apps/web --- Next.js application

-   apps/api --- FastAPI application

-   workers/parser --- background parsing worker

-   packages/contracts --- generated/shared API schemas

-   packages/ui --- shared frontend components

-   packages/config --- shared configuration

-   infra/docker --- local containers

-   infra/terraform --- cloud infrastructure

-   tests/e2e --- Playwright tests

-   tests/evaluation --- resume ground-truth evaluation

# 13. Recommended Data Pipeline

1\. Validate file → 2. Virus/malware scan in production → 3. Extract
text/layout → 4. Detect OCR requirement → 5. Segment sections → 6. LLM
structured extraction → 7. Pydantic validation → 8. Normalize entities →
9. Attach evidence → 10. Calculate extraction confidence → 11. Generate
embeddings → 12. Persist → 13. Notify client.

# 14. Observability

Use OpenTelemetry as the vendor-neutral instrumentation layer for
traces, metrics, and logs. OpenTelemetry is designed to generate,
collect, and export telemetry and supports multiple backends without
locking the application to one vendor. citeturn0search0turn0search5

-   Trace each resume through the complete processing pipeline.

-   Record parser, OCR, LLM, database, and embedding latency.

-   Track queue depth and worker throughput.

-   Track extraction failures by stage.

-   Use Sentry for application exceptions and actionable error tracking.

# 15. Testing Stack

  -----------------------------------------------------------------------
  Tool                    Scope                   Examples
  ----------------------- ----------------------- -----------------------
  Pytest                  Backend/unit            Schemas, parsers,
                                                  services

  Vitest                  Frontend/unit           Hooks, utilities,
                                                  components

  Playwright              End-to-end              Upload → parse →
                                                  profile

  Evaluation dataset      AI quality              Precision, recall, F1

  Load testing            Scalability             Concurrent uploads/jobs
  -----------------------------------------------------------------------

# 16. Security Architecture

-   Private object-storage buckets.

-   Signed URLs with short expiration.

-   MIME and magic-byte validation.

-   File-size limits.

-   Sandboxed document processing.

-   Rate limiting on upload and search APIs.

-   Secrets stored in a cloud secret manager.

-   No raw resume content in application logs.

-   Encryption in transit and at rest.

-   Per-user/per-organization authorization checks.

# 17. Local Development

Docker Compose should provide a one-command local environment.

-   web

-   api

-   worker

-   postgres

-   redis

-   local object storage such as MinIO

The same environment should be suitable for onboarding a new contributor
without requiring cloud services for every development task.

# 18. Production Deployment

Recommended production path:

Vercel or equivalent → Next.js frontend; AWS ECS/Fargate → FastAPI +
workers; Amazon RDS PostgreSQL → database; S3 → documents; ElastiCache
Redis → queue/cache; OpenTelemetry + Sentry → observability.

For a portfolio MVP, a lower-cost deployment can use Vercel +
Render/Railway/Fly.io + managed PostgreSQL + managed Redis +
S3-compatible storage. The application architecture should remain
cloud-agnostic.

# 19. Scaling Strategy

-   Scale API instances horizontally.

-   Scale parser workers independently from API instances.

-   Use queue backpressure for bursts.

-   Keep API servers stateless.

-   Use PostgreSQL connection pooling.

-   Use object storage instead of database blobs for original documents.

-   Add pgvector indexes as the corpus grows.

-   Introduce caching only after measuring a real bottleneck.

-   Move to Temporal or a dedicated workflow engine only when workflow
    complexity justifies it.

# 20. Cost-Control Strategy

-   Run deterministic parsing before calling an LLM.

-   Send only relevant text/sections to the model when possible.

-   Use smaller models for classification/normalization tasks.

-   Cache stable normalization results.

-   Generate embeddings once and reuse them.

-   Process OCR only when needed.

-   Track model tokens and cost per resume.

# 21. Why This Stack

  ------------------------------------------------------------------------
  Decision                Reason                   Trade-off
  ----------------------- ------------------------ -----------------------
  Next.js + TypeScript    Strong interactive UI    Separate Python API
                          and modern React         still needed
                          architecture             

  FastAPI + Python        Excellent AI/document    Two-language system
                          ecosystem and async API  
                          support                  

  PostgreSQL + pgvector   One source of truth plus May require dedicated
                          vector search            vector infrastructure
                                                   at very large scale

  Redis + ARQ             Simple and effective     Less workflow
                          async job processing     durability than
                                                   Temporal

  S3                      Durable scalable file    Cloud dependency
                          storage                  

  OpenTelemetry           Vendor-neutral           Requires initial
                          observability            instrumentation work

  Docker                  Reproducible             Container complexity
                          development/deployment   
  ------------------------------------------------------------------------

# 22. Implementation Phases

## Phase 1 --- Foundation

-   Next.js

-   FastAPI

-   PostgreSQL

-   Docker

-   Resume upload

-   Basic parsing

## Phase 2 --- Intelligence

-   Pydantic extraction schemas

-   LLM adapter

-   Evidence

-   Confidence

-   OCR

-   Normalization

## Phase 3 --- Scale

-   Redis

-   Workers

-   S3

-   Retries

-   Rate limiting

-   Observability

## Phase 4 --- Search

-   Embeddings

-   pgvector

-   Semantic search

-   Job matching

## Phase 5 --- Production

-   Authentication

-   Multi-tenancy

-   API keys

-   CI/CD

-   AWS deployment

-   Security hardening

# 23. Final Recommendation

For this project, the recommended baseline is: Next.js 16 + TypeScript +
Tailwind + Motion on the frontend; FastAPI + Python + Pydantic on the
backend; PyMuPDF + python-docx + PaddleOCR for document processing; a
provider-agnostic structured-output LLM layer; PostgreSQL 18 + pgvector
for persistence and semantic search; Redis + ARQ for asynchronous
processing; S3 for files; Docker + GitHub Actions for delivery; and
OpenTelemetry + Sentry for observability.

This stack is deliberately modular. It is simple enough to build as a
solo portfolio project, while the boundaries are appropriate for scaling
into a real multi-tenant resume intelligence service.

# 24. Current Technology References

The stack recommendations were checked against current official
documentation available in September 2026.

-   Next.js official documentation and current release information.
    citeturn0search2turn0search3

-   FastAPI async/concurrency documentation. citeturn0search7

-   pgvector project documentation and current capabilities.
    citeturn0search1turn0search10

-   OpenTelemetry documentation and architecture guidance.
    citeturn0search0turn0search5turn0search11
