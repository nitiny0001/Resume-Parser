---
title: Product Requirements Document
---

**Resume Intelligence Platform**

Version 1.0 \| Status: Proposed \| Product Type: AI-powered SaaS /
Portfolio Project

# 1. Product Overview

## 1.1 Problem

Resumes are unstructured documents containing information about a
candidate's education, experience, projects, skills, certifications,
achievements, and contact information. Traditional resume parsers often
struggle with different layouts, multi-column PDFs, tables, scanned
documents, contextual skill understanding, and traceability to the
original document.

## 1.2 Proposed Solution

Build an AI-powered Resume Intelligence Platform that converts resumes
into validated, structured candidate profiles. The platform combines
document parsing, OCR, layout analysis, LLM-based information
extraction, schema validation, entity normalization, confidence scoring,
evidence tracking, semantic embeddings, search, and matching.

-   Web interface for candidates and recruiters

-   REST API for application integrations

-   Asynchronous processing for scalable workloads

-   Explainable extraction with evidence and confidence

# 2. Product Vision

Turn an unstructured resume into a reliable, explainable,
machine-readable candidate profile.

# 3. Goals

-   Parse PDF and DOCX resumes.

-   Extract structured candidate information.

-   Handle different resume layouts.

-   Support scanned/image-based documents through OCR.

-   Validate extracted information.

-   Provide extraction confidence and evidence.

-   Normalize skills and technologies.

-   Provide searchable candidate profiles.

-   Expose parsing functionality through a REST API.

-   Support asynchronous processing and horizontal scaling.

-   Deploy as a production-ready application.

# 4. Non-Goals --- V1

-   Automatically reject candidates.

-   Make hiring decisions.

-   Determine whether a candidate is suitable for employment.

-   Verify employment claims against external databases.

-   Perform background checks.

-   Infer sensitive personal characteristics.

-   Generate a complete resume from scratch.

# 5. Target Users

## 5.1 Candidate

Uploads a resume and receives a structured profile, extracted skills,
experience timeline, parsing warnings, confidence indicators, and
quality insights.

## 5.2 Recruiter

Uploads and searches candidate profiles using skills, experience,
education, technologies, certifications, projects, and semantic queries.

## 5.3 Developer / Integrator

Uses the API to integrate resume parsing into ATS, HR, recruitment, or
job-platform applications.

# 6. Core User Journey

User → Upload Resume → File Validation → Document Processing → OCR if
required → Layout Analysis → Section Detection → AI Extraction → Schema
Validation → Normalization → Confidence Scoring → Structured Profile →
Web UI / API

# 7. Functional Requirements

## FR-001 --- Resume Upload

-   Support PDF and DOCX.

-   Configurable maximum file size.

-   Reject unsupported MIME types.

-   Validate file signatures rather than relying only on extensions.

## FR-002 --- PDF Extraction

-   Extract text, page numbers, coordinates where available, font
    information where available, images, and tables.

-   Preserve document structure where possible.

## FR-003 --- DOCX Extraction

-   Extract paragraphs, headings, tables, hyperlinks, and lists.

## FR-004 --- OCR

-   Detect image/scanned documents.

-   Run OCR while preserving page references and coordinates where
    possible.

## FR-005 --- Section Detection

-   Detect CONTACT, SUMMARY, EDUCATION, EXPERIENCE, INTERNSHIPS,
    PROJECTS, SKILLS, CERTIFICATIONS, ACHIEVEMENTS, PUBLICATIONS,
    LANGUAGES, and INTERESTS.

-   Normalize synonymous headings such as Work Experience, Professional
    Experience, Employment, and Career History.

## FR-006 --- Information Extraction

-   Extract candidate contact data, education, experience, projects,
    skills, certifications, achievements, and links.

## FR-007 --- Evidence Tracking

-   Attach source page, section, and supporting text to important
    extracted entities.

## FR-008 --- Confidence Scoring

-   Calculate extraction confidence from model confidence, validation,
    consistency, evidence availability, and document quality.

## FR-009 --- Entity Normalization

-   Map variants such as ReactJS, React.js, React JS, and React to a
    canonical entity.

## FR-010 --- Semantic Skill Understanding

-   Understand relationships between technologies and categories rather
    than relying only on exact keywords.

## FR-011 --- Resume Embeddings

-   Generate embeddings for resume, experience, projects, and skills for
    semantic search.

## FR-012 --- Search

-   Support structured filters and semantic search across candidate
    profiles.

## FR-013 --- Resume Analysis

-   Identify missing information, parsing warnings, and data-quality
    issues.

## FR-014 --- Human Correction

-   Allow users to edit extracted fields and retain corrections
    separately from raw extraction output.

## FR-015 --- REST API

-   Provide endpoints for upload, status, profile retrieval, and search.

## FR-016 --- Async Processing

-   Use a queue and worker architecture so parsing does not block HTTP
    requests.

# 8. Structured Output

The canonical profile should include candidate information, summary,
education, experience, projects, skills, certifications, achievements,
links, metadata, confidence, evidence, and warnings. All persisted
output must pass typed schema validation before database storage.

# 9. Example Evidence Object

Example: { \"value\": \"React\", \"confidence\": 0.97, \"source\": {
\"page\": 2, \"section\": \"Projects\", \"text\": \"Built the frontend
using React\...\" } }

Confidence is an extraction-confidence indicator, not an absolute
probability of correctness.

# 10. Technology Requirements

  -------------------------------------------------------------------------
  Layer                   Technology              Purpose
  ----------------------- ----------------------- -------------------------
  Frontend                Next.js + TypeScript +  Web application
                          Tailwind                

  Backend                 FastAPI + Python        REST API and business
                                                  logic

  Async                   Redis + Celery/ARQ      Background parsing jobs

  Database                PostgreSQL              Structured persistence

  Vector Search           pgvector                Semantic search

  Document Parsing        PyMuPDF + python-docx   PDF/DOCX extraction

  OCR                     PaddleOCR               Scanned documents

  AI                      Structured-output LLM   Semantic extraction

  Validation              Pydantic                Typed schemas

  Storage                 S3-compatible object    Original documents
                          storage                 

  Deployment              Docker + cloud platform Production deployment

  CI/CD                   GitHub Actions          Automated
                                                  builds/tests/deployment

  Observability           OpenTelemetry + Sentry  Tracing, metrics, errors
  -------------------------------------------------------------------------

# 11. High-Level Architecture

Frontend → API Gateway → Upload/File Service → Queue → Parser Workers →
Text/Layout/OCR → Section Detection → LLM Extraction → Pydantic
Validation → Normalization → Confidence/Evidence → PostgreSQL + pgvector
→ API/Web UI

# 12. Data Model

-   User

-   Resume

-   Document

-   CandidateProfile

-   Education

-   Experience

-   Project

-   Skill

-   Certification

-   Achievement

-   ExtractionRun

-   ExtractionEvidence

-   Embedding

-   ParserWarning

-   UserCorrection

-   SearchHistory

# 13. AI Architecture

The LLM must not directly control the database. The pipeline is:
Document → Prompt → Structured JSON → Pydantic validation → Business
validation → Database. Invalid output must be rejected or repaired
before persistence.

# 14. Scalability Requirements

-   API instances must be stateless and horizontally scalable.

-   Parser workers must scale independently.

-   Queue-based processing must support concurrent jobs.

-   Object storage must separate large files from transactional database
    data.

-   Database connections and external model calls must be managed with
    appropriate pooling, retries, and timeouts.

# 15. Security Requirements

-   Validate MIME types and file signatures.

-   Enforce file size limits.

-   Sandbox document processing.

-   Use authentication and authorization.

-   Implement API rate limiting.

-   Encrypt data in transit and at rest.

-   Never expose resumes through public URLs.

-   Do not log raw resume contents.

-   Delete temporary files after processing.

-   Provide user-controlled resume deletion.

# 16. Privacy

Resumes contain personally identifiable information. The system must
minimize PII exposure, define retention periods, restrict access by user
or organization, secure stored documents, and avoid unnecessary logging
of resume contents.

# 17. Performance Targets

  -----------------------------------------------------------------------
  Metric                              Initial Target
  ----------------------------------- -----------------------------------
  Upload response                     \< 2 seconds

  Normal resume parsing               \< 30 seconds

  API p95 latency                     \< 500 ms

  Search p95 latency                  \< 1 second

  Concurrent parsing jobs             50+

  Availability target                 99.9%
  -----------------------------------------------------------------------

# 18. Evaluation Strategy

Create a manually verified ground-truth dataset of resumes and measure
field-level Precision, Recall, and F1. Track extraction quality
separately for contact data, skills, experience, education, projects,
and other entities. Evaluation metrics must be measured experimentally
rather than assumed.

# 19. Testing Strategy

-   Unit tests for extraction helpers, date normalization, skill
    normalization, and schema validation.

-   Integration tests for upload → queue → worker → extraction →
    database.

-   Document corpus tests covering standard PDFs, two-column resumes,
    table-heavy resumes, DOCX, and scanned resumes.

-   Regression testing against the evaluation dataset after parser
    changes.

# 20. MVP Scope

-   PDF and DOCX upload

-   Text extraction

-   Basic OCR

-   Section detection

-   LLM extraction

-   Pydantic validation

-   Structured JSON

-   PostgreSQL persistence

-   Basic dashboard

-   REST API

-   Dockerized development environment

# 21. V2 Scope

-   Evidence tracking

-   Confidence scoring

-   Skill normalization

-   Embeddings

-   Semantic search

-   Resume quality analysis

-   Batch uploads

-   Background workers

-   Authentication

-   Usage analytics

# 22. V3 Scope

-   Job description matching

-   Skill-gap analysis

-   Candidate search

-   Multi-tenant organizations

-   API keys

-   Usage quotas

-   Billing

-   Advanced analytics

-   Evaluation dashboard

# 23. Success Metrics

-   Successful parsing rate

-   Average parsing time

-   User correction rate

-   Resume processing completion rate

-   Field-level extraction F1

-   Normalization accuracy

-   Evidence coverage

-   API p95 latency

-   Worker throughput

-   Queue processing time

-   Infrastructure cost per resume

# 24. Definition of Done --- V1

-   User can upload PDF and DOCX resumes.

-   System can process text-based and scanned resumes.

-   System detects major resume sections.

-   System extracts candidate, education, experience, projects, skills,
    certifications, and achievements.

-   System validates extracted output.

-   System stores structured profiles.

-   User can view and edit extracted information.

-   System exposes parsing through an API.

-   Parsing is asynchronous.

-   Automated tests cover core functionality.

-   Application runs through Docker.

-   Application is deployed publicly.

-   Failures and latency are observable.

# 25. Delivery Roadmap

  -----------------------------------------------------------------------
  Timeline                            Deliverables
  ----------------------------------- -----------------------------------
  Week 1                              Repository setup, FastAPI,
                                      PostgreSQL, Next.js, Docker, resume
                                      upload

  Week 2                              PDF/DOCX parsing, section
                                      detection, Pydantic schemas, basic
                                      extraction

  Week 3                              LLM extraction, validation,
                                      evidence, confidence, persistence

  Week 4                              Redis, workers, dashboard, tests,
                                      deployment
  -----------------------------------------------------------------------

# 26. Product Differentiator

The primary differentiator is explainable resume intelligence rather
than simple resume parsing. The platform should connect extracted
entities to evidence, confidence, normalized concepts, and semantic
representations, creating a foundation for search, matching, and
analytics.
