---
title: Design Document
---

**Resume Intelligence Platform**

Version 1.0 \| Status: Proposed \| Design Direction: Premium Animated AI
SaaS

# 1. Design Objective

The Resume Intelligence Platform should feel like a premium AI product
rather than a conventional HR/ATS dashboard. The visual language should
communicate intelligence, precision, technical sophistication, speed,
trust, and modernity.

Core principle: The interface should make the complexity of the AI
pipeline feel simple.

# 2. Design Principles

-   Minimal --- avoid unnecessary cards, borders, badges, and visual
    noise.

-   Motion-first --- use subtle transitions instead of abrupt state
    changes.

-   Strong hierarchy --- important information should dominate visually.

-   Progressive disclosure --- reveal details from profile to section to
    entity to evidence.

-   Explainability --- important extracted information should be
    traceable to its source.

-   Performance-aware motion --- animation must never compromise
    usability or responsiveness.

# 3. Application Structure

-   Landing --- product introduction and animated hero.

-   Dashboard --- overview of resumes and candidate profiles.

-   Upload --- drag-and-drop document ingestion.

-   Resume --- parsed candidate profile and evidence.

-   Search --- structured and semantic candidate discovery.

-   Settings --- account, API, privacy, and application preferences.

# 4. Landing Page

## 4.1 Hero

The hero should immediately communicate that the product converts
unstructured resumes into structured intelligence.

Suggested hierarchy: large headline → short explanatory copy → primary
CTA → animated resume-to-profile visualization.

## 4.2 Hero Animation

A resume document enters the viewport. The system visually progresses
through Extracting → Understanding → Structuring → Validated Profile.
Extracted entities can emerge from the document and converge into a
structured candidate profile.

# 5. Upload Experience

The upload interface should be extremely simple and focused.

-   Drop zone with PDF/DOCX support information.

-   Browse button.

-   Drag-over state with subtle scale, border, and glow animation.

-   Upload progress state.

-   Validation errors presented inline.

# 6. Parsing Experience

Avoid a generic loading spinner. Show the actual AI processing pipeline
so users understand what is happening.

-   Document detected

-   Text extracted

-   Sections identified

-   Understanding experience

-   Normalizing skills

-   Validating entities

-   Generating profile

Completed stages should animate into place. Processing should remain
understandable even when individual stages take different amounts of
time.

# 7. Main Dashboard

The dashboard should use strong editorial hierarchy rather than a dense
enterprise dashboard.

-   Profile confidence

-   Candidate summary

-   Skills

-   Experience

-   Education

-   Projects

-   Warnings

-   Recent parsing activity

# 8. Candidate Profile

The candidate profile should feel like a digital identity rather than an
HR database record.

-   Candidate name and professional/education headline.

-   Timeline or date range.

-   GitHub, LinkedIn, portfolio, and relevant links.

-   Summary metrics such as skills, projects, experience, and education.

-   Expandable evidence and source references.

# 9. Skills Visualization

Skills should be presented as meaningful entities rather than a flat
list. The initial version can use categorized groups; a later version
can introduce an interactive skill graph showing relationships between
technologies, frameworks, and domains.

Example relationship: React → JavaScript ecosystem → Frontend → Web
development.

# 10. Evidence Interaction

Evidence is a core product differentiator. Selecting an extracted entity
such as React should reveal its confidence, the section where it was
detected, supporting text, and page reference.

-   Entity name

-   Confidence indicator

-   Source section

-   Supporting text

-   Page number

-   Optional link to the corresponding region in the original resume

# 11. Experience Timeline

Use a vertical or horizontal timeline to represent education, projects,
internships, and professional experience chronologically. Entries should
progressively reveal as the user scrolls or interacts with the timeline.

# 12. Project Cards

Project cards should show project name, concise description, technology
stack, and an evidence action. Hover interactions may introduce subtle
elevation, technology movement, and directional-arrow motion.

# 13. Search Interface

Search should feel like an AI interface rather than a conventional
database filter.

-   Natural-language semantic queries.

-   Structured filters for skills, experience, education, location, and
    certifications.

-   Candidate result cards with relevant skills and semantic-match
    context.

Example query: "Find candidates who have built distributed backend
systems using Kafka."

# 14. Animation System

## 14.1 Page Transitions

Use short opacity and vertical-position transitions for page entry.
Avoid excessive transition choreography.

## 14.2 Cards

Cards can use subtle scale and opacity transitions on entrance and
slight elevation on hover.

## 14.3 Numbers

Metrics such as confidence can animate from zero to their final
displayed value.

## 14.4 Processing Pipeline

Pipeline stages should transition between pending, processing, and
complete states.

# 15. Visual Language

-   Use a restrained dark or neutral visual foundation.

-   Use slightly differentiated surfaces for hierarchy.

-   Use large expressive display typography for major headings.

-   Use a clean sans-serif for application content.

-   Use one primary accent for active states, confidence, links, and
    CTAs.

-   Avoid excessive multicolor gradients or rainbow-style AI dashboards.

Exact colors and typography should be calibrated against the provided
visual reference before final implementation.

# 16. Typography Hierarchy

  -----------------------------------------------------------------------
  Element                             Suggested Size
  ----------------------------------- -----------------------------------
  Hero                                72--96 px

  Page heading                        48--64 px

  Section heading                     28--36 px

  Card heading                        18--22 px

  Body                                14--16 px

  Metadata                            12--13 px
  -----------------------------------------------------------------------

# 17. Component System

-   Button

-   Navigation

-   Hero

-   UploadZone

-   ProcessingPipeline

-   ConfidenceScore

-   SkillBadge

-   SkillGraph

-   ExperienceTimeline

-   ProjectCard

-   EvidencePanel

-   ResumeViewer

-   SearchBar

-   CandidateCard

-   Metric

-   Modal

-   Toast

# 18. Frontend Architecture

Recommended frontend architecture: Next.js App Router + TypeScript +
Tailwind CSS + Framer Motion + React Query + Zod.

-   Use server state for resumes, parsing status, candidate profiles,
    and search results.

-   Use local state for modals, filters, animation state, and UI
    preferences.

-   Prefer reusable primitives and composition over page-specific
    components.

# 19. Design Tokens

Centralize the visual system into tokens for colors, typography,
spacing, radius, shadows, motion, easing, and breakpoints.

-   \--radius-sm / \--radius-md / \--radius-lg

-   \--duration-fast / \--duration-normal / \--duration-slow

-   \--ease-standard / \--ease-emphasized

-   Color and typography scales

-   Spacing and layout scales

# 20. Responsive Design

## 20.1 Desktop

Desktop is the primary experience and may use multi-column layouts, side
panels, timelines, and evidence drawers.

## 20.2 Tablet

Collapse secondary panels and reduce horizontal density.

## 20.3 Mobile

Transform multi-column layouts into a vertical flow: Profile →
Experience → Projects → Skills → Evidence. Reduce animation complexity
on constrained devices.

# 21. Accessibility

-   Keyboard navigation throughout the application.

-   Visible focus states.

-   Semantic HTML.

-   Accessible labels and controls.

-   Sufficient color contrast.

-   Reduced-motion support using prefers-reduced-motion.

-   Never make critical information available only through animation.

# 22. Performance

-   Target smooth 60 FPS for common animations.

-   Prefer GPU-friendly transform and opacity animations.

-   Avoid unnecessary layout-triggering animations.

-   Lazy-load heavy visualizations.

-   Virtualize large candidate result lists.

-   Optimize document previews and large resume assets.

# 23. Design-to-Code Workflow

Reference Design → Visual Analysis → Design Tokens → Component Inventory
→ Page Layouts → Animation Specification → Responsive Specification →
Next.js Implementation.

The reference shot should be treated as inspiration for the visual
language. Final product UI should adapt the visual principles to the
information architecture and usability requirements of the Resume
Intelligence Platform.

# 24. Screen Inventory

  -----------------------------------------------------------------------
  Screen                  Priority                Primary Purpose
  ----------------------- ----------------------- -----------------------
  Landing                 P0                      Explain product and
                                                  drive resume upload

  Upload                  P0                      Ingest PDF/DOCX resume

  Processing              P0                      Communicate AI parsing
                                                  progress

  Candidate Dashboard     P0                      Present parsed profile

  Evidence Panel          P0                      Explain extracted
                                                  entities

  Search                  P1                      Find candidates
                                                  semantically

  Resume Viewer           P1                      Inspect source document

  Settings                P2                      Account and preferences
  -----------------------------------------------------------------------

# 25. Design Acceptance Criteria

-   The landing page communicates the product purpose within a few
    seconds.

-   Upload interactions provide clear visual feedback.

-   Parsing progress communicates meaningful system stages.

-   The candidate profile is scannable without opening every detail.

-   Important extracted entities expose evidence and confidence.

-   Desktop, tablet, and mobile layouts remain usable.

-   Animations are consistent across the product.

-   Reduced-motion mode is supported.

-   No core information depends exclusively on animation.

-   The visual system is implemented through reusable components and
    tokens.

# 26. Implementation Notes

The design should be implemented as a reusable design system rather than
a collection of one-off pages. Motion should reinforce state and
hierarchy. The first implementation should prioritize the Landing,
Upload, Processing, Candidate Profile, and Evidence experiences; Search
and advanced visualizations can follow after the core parsing workflow
is stable.

# 27. Reference Limitation

The supplied Dribbble URL could not be reliably inspected in the current
environment. Consequently, this document defines the intended premium
animated visual direction and product-specific design system without
claiming exact measurements or visual details from the referenced shot.
A screenshot of the reference should be used for pixel-level comparison
and final token calibration.
